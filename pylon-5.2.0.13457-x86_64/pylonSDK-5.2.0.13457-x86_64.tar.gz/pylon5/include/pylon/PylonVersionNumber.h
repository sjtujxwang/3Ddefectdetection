// This file has been generated automatically using:
// "/home/jenkins/workspace/pylon_release_5.2/Build/FileTemplates/PylonVersionNumber.template.h"
// DO NOT EDIT!

#define PYLON_VERSION_MAJOR           5
#define PYLON_VERSION_MINOR           2
#define PYLON_VERSION_SUBMINOR        0
#define PYLON_VERSION_BUILD           13457
#define PYLON_VERSIONSTRING_MAJOR     "5"
#define PYLON_VERSIONSTRING_MINOR     "2"
#define PYLON_VERSIONSTRING_SUBMINOR  "0"
#define PYLON_VERSIONSTRING_BUILD     "13457"
#define PYLON_VERSIONSTRING_EXTENSION ""
