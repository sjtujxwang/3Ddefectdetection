var searchData=
[
  ['quality',['Quality',['../class_basler___video_writer_params_1_1_c_video_writer_params___params.html#aceb7cb155a1817ad48c67693bfc7ded6',1,'Basler_VideoWriterParams::CVideoWriterParams_Params']]]
];
